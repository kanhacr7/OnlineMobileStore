package com.mycompany.oms.common;

//Class to define the roles of user

public class UserConstant {
	public static final String DEFAULT_ROLE = "Customer";
    public static final String ADMIN_ACCESS= "Admin";

}
