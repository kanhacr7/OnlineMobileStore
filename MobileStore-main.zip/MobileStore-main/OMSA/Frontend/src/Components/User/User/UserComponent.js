import React, { Component } from "react";
import Navbarcust from "../Navbar/navbarcustomer";
class UserComponent extends Component{
    render(){
        return(
            <div>
                <Navbarcust></Navbarcust>
            <h3 >Home</h3>
            </div>
        )
    }
}
export default UserComponent;